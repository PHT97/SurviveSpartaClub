using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    public static GameManager instance;
    public int clearnum = DoorManager.dungeonNum;
    public float Timer = 20f;
    public Transform Player { get; private set; }
    [SerializeField] private string playerTag = "Player";
    private HealthSystem playerHealthSystem;

    [SerializeField] private TextMeshProUGUI Time;
    [SerializeField] private TextMeshProUGUI ClearDungeonNum;
    [SerializeField] private TextMeshProUGUI HPNum;

    public GameObject gameOverUI;
    public GameObject Canvas;

    //
    public GameObject MainCamera;
    public GameObject PlayerObject;
    //


    private void Awake()
    {
        instance = this;
        Player = GameObject.FindGameObjectWithTag(playerTag).transform;

        playerHealthSystem = Player.GetComponent<HealthSystem>();
        playerHealthSystem.OnDeath += GameOver;

        gameOverUI.SetActive(false);

    }
    private void Start()
    {

    }
    private void Update()
    {

    }
    private void UpdateTimeUI()
    {
        
    }
    public void UpdateClearDungeonUI()
    {
        
    }
    private void GameOver()
    {
        gameOverUI.SetActive(true);
    }
    public void RestartGame()
    {
        Destroy(gameObject);
        Destroy(PlayerObject);
        Destroy(MainCamera);
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }
    public void ExitGame()
    {
        Destroy(gameObject);
        Destroy(PlayerObject);
        Destroy(MainCamera);
        SceneManager.LoadScene("StartScene");
    }
}